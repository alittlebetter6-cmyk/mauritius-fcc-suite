# Deploying from your phone — step by step

This gets you a real web link (`yourapp.streamlit.app`) you can open like any
website. No laptop needed. Takes about 10–15 minutes.

Replace `YOURNAME` and `mauritius-fcc-suite` below with your actual GitHub
username and the repo name you choose.

---

## 1. Unzip the download

In your phone's **Files** app (iOS) or file manager (Android), tap the
`mauritius-fcc-suite.zip` file — both platforms extract it in place, giving
you a `mauritius-fcc-suite` folder.

## 2. Create a GitHub account + empty repo

1. Go to **github.com** in your browser, sign up if you don't have an account.
2. Tap the **+** icon (top right) → **New repository**.
3. Name it `mauritius-fcc-suite`. Leave it **Public**. Do **not** tick
   "Add a README" — leave it completely empty.
4. Tap **Create repository**.

## 3. Upload the files — folder by folder

Mobile browsers can't upload a whole folder tree in one go (the "choose
files" picker only grabs individual files). GitHub has a feature that makes
this easy anyway: type a folder path straight into the upload URL and it
creates that folder for you.

For each step below, **type the URL directly into your browser's address
bar** (don't tap around the UI — it's faster and more reliable on mobile),
then use **"choose your files"** to multi-select the listed files from where
you unzipped them, and tap **Commit changes** at the bottom.

*(If typing the URL doesn't land you where expected: from the repo's main
page, tap **Add file → Create new file**, type the folder name followed by
a `/` in the filename box — e.g. `fcc_suite/` — which opens that folder,
then use **Add file → Upload files** from there instead.)*

**Step 3a — root files**
```
github.com/YOURNAME/mauritius-fcc-suite/upload/main/
```
Select: `app.py`, `requirements.txt`, `run.sh`, `README.md`, `.gitignore`

**Step 3b — the fcc_suite package**
```
github.com/YOURNAME/mauritius-fcc-suite/upload/main/fcc_suite
```
Select: `__init__.py`, `ai_engine.py`, `legislation.py`, `matching.py`,
`news.py`, `risk.py`, `sanctions.py`, `store.py`

**Step 3c — the data files**
```
github.com/YOURNAME/mauritius-fcc-suite/upload/main/fcc_suite/data
```
Select: `legislation.json`, `mu_nss.json`, `sample_sanctions.json`

That's everything the app needs to run. (`tests/` is optional — skip it
unless you want to re-run verification later.)

**Check your work:** open `github.com/YOURNAME/mauritius-fcc-suite` and
confirm you see a `fcc_suite` folder containing a `data` folder, sitting
alongside `app.py` at the top level. If `app.py` isn't directly visible on
the repo's front page, something landed in the wrong folder — redo that
upload step at the correct URL.

## 4. Deploy on Streamlit Community Cloud

1. Go to **share.streamlit.io**, tap **Sign in**, choose **Continue with
   GitHub**, and authorize it.
2. Tap **Create app** → **From an existing repo**.
3. Fill in:
   - **Repository:** `YOURNAME/mauritius-fcc-suite`
   - **Branch:** `main`
   - **Main file path:** `app.py`
4. Tap **Deploy**. First build takes a few minutes — you'll see build logs
   scroll past. When it finishes you land on your live app.

## 5. (Optional) Turn on the AI Analyst tab

1. On your app's page, tap the **⋮** menu → **Settings** → **Secrets**.
2. Paste in:
   ```
   ANTHROPIC_API_KEY = "sk-ant-your-key-here"
   ```
3. Save. The app restarts automatically and the AI Analyst tab lights up
   green. Everything else works without this step.

---

## Good to know

- **The case/audit database resets** whenever the free-tier app restarts or
  redeploys (sleeps after inactivity, wakes on next visit). Fine for trying
  it out; for real casework you'll eventually want it pointed at a proper
  database — ask and I'll wire that in.
- **To update the app later**, upload a changed file again at the same
  `/upload/main/...` path — GitHub treats it as a new commit and Streamlit
  Cloud redeploys automatically.
- **If a build fails**, the Cloud dashboard shows the error log — copy the
  relevant lines back to me and I'll fix it directly.
