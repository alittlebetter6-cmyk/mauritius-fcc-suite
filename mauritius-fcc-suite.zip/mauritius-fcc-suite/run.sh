#!/usr/bin/env bash
set -e
python3 -m pip install -r requirements.txt
# Optional: export your key to enable the AI analyst tab
# export ANTHROPIC_API_KEY=sk-ant-...
streamlit run app.py
