"""
Full verification suite for Mauritius FCC Suite.
Run: python3 tests/test_suite.py
Covers: matching, sanctions (incl. NSS + parsers + cache fallback), legislation,
risk, store (cases, adjudication, audit chain, tamper detection, export),
ai_engine (offline behaviour), news (parser), and app.py import structure.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# isolate runtime DB for tests
os.environ["FCC_DB"] = str(Path(tempfile.mkdtemp()) / "test_fcc.db")

PASS, FAIL = 0, 0
FAILURES: list[str] = []


def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        FAILURES.append(f"{name} {detail}")
        print(f"  ❌ {name} {detail}")


def section(title: str):
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------- matching
section("matching — normalisation & fuzzy screening")
from fcc_suite import matching

check("normalise strips accents/punct",
      matching.normalise("Café-José  O'Brien!") == "cafe jose o brien")
check("entity suffix stripped",
      matching.prepare("Alpha Trading Ltd", True) == matching.prepare("Alpha Trading Limited", True))
s = matching.similarity("Ivan Volkov", "Ivan Petrov Volkov")
check("middle-name variant scores high", s >= 92, f"(got {s})")
s2 = matching.similarity("MOHAMMED KHAN", "Mohamed Kan")
check("transliteration variant scores high", s2 >= 82, f"(got {s2})")
s3 = matching.similarity("John Smith", "Alpha Trading Ltd")
check("unrelated names score low", s3 < 60, f"(got {s3})")

recs = [
    {"name": "Ivan Petrov Volkov", "aka": ["I. Volkov"], "list": "T"},
    {"name": "Golden Sands Holdings", "aka": ["Golden Sands Ltd"], "list": "T"},
]
r = matching.screen_name("Ivan Volkov", recs)
check("screen finds hit", r.hits and r.hits[0].matched_name == "Ivan Petrov Volkov")
check("band STRONG at >=92", r.band == "STRONG", f"(got {r.band}, {r.top_score})")
r2 = matching.screen_name("Zzyzx Nobody", recs)
check("clean name -> CLEAR, 0 hits", r2.band == "CLEAR" and not r2.hits)
r3 = matching.screen_name("Golden Sands Limited", recs, is_entity=True)
check("aka + suffix matching", r3.hits and r3.top_score >= 92, f"(got {r3.top_score})")
r4 = matching.screen_name("", recs)
check("empty query safe", r4.band == "CLEAR" and not r4.hits)
# threshold respected
r5 = matching.screen_name("Ivan Volkov", recs, threshold=99.5)
check("high threshold filters", all(h.score >= 99.5 for h in r5.hits))

# ---------------------------------------------------------------- sanctions
section("sanctions — parsers, cache fallback, NSS register")
from fcc_suite import sanctions

# parser: UN XML
un_xml = b"""<CONSOLIDATED_LIST><INDIVIDUALS><INDIVIDUAL>
<FIRST_NAME>ABC</FIRST_NAME><SECOND_NAME>DEF</SECOND_NAME>
<UN_LIST_TYPE>DPRK</UN_LIST_TYPE>
<INDIVIDUAL_ALIAS><ALIAS_NAME>A. DEF</ALIAS_NAME></INDIVIDUAL_ALIAS>
</INDIVIDUAL></INDIVIDUALS>
<ENTITIES><ENTITY><FIRST_NAME>EVIL CORP</FIRST_NAME><UN_LIST_TYPE>DPRK</UN_LIST_TYPE></ENTITY></ENTITIES>
</CONSOLIDATED_LIST>"""
p = sanctions._parse_un_xml(un_xml)
check("UN XML parser: individual + entity", len(p) == 2)
check("UN XML alias captured", p[0]["aka"] == ["A. DEF"])
check("UN XML entity typed", p[1]["type"] == "entity")

# parser: OFAC CSV
ofac_csv = b'1234,"VOLKOV, Ivan","individual","UKRAINE-EO13662","-0-"\n5678,"SHADY SHIPPING LLC","-0-","SDGT","-0-"\n'
p2 = sanctions._parse_ofac_csv(ofac_csv)
check("OFAC CSV parser: 2 rows", len(p2) == 2)
check("OFAC individual typed", p2[0]["type"] == "individual" and p2[1]["type"] == "entity")

# parser: UK CSV (with title line before header)
uk_csv = ("Last Updated:01/07/2026\n"
          "Name 1,Name 2,Name 3,Name 4,Name 5,Name 6,Group Type,Regime\n"
          "JOHN,,DOE,,,,Individual,Russia\n"
          "ACME,ARMS,,,,,Entity,Syria\n").encode()
p3 = sanctions._parse_uk_csv(uk_csv)
check("UK CSV parser handles title line", len(p3) == 2)
check("UK names joined", p3[0]["name"] == "JOHN DOE")

# cache round-trip + fallback behaviour
sanctions._write_cache("TESTLIST", [{"name": "Cached Person", "aka": [], "list": "TESTLIST"}])
c = sanctions._read_cache("TESTLIST")
check("cache write/read round-trip", c and c["records"][0]["name"] == "Cached Person")

# network fetch of real UN list will fail in sandbox -> must degrade gracefully
recs_un, st_un = sanctions.fetch_list("UN")
check("blocked fetch degrades (no crash)", st_un.source in ("demo", "cache"))

# demo fallback when no live data at all
allrecs, statuses = sanctions.load_all()
srcs = {s.code: s for s in statuses}
check("demo fallback engaged", "DEMO" in srcs and srcs["DEMO"].count == 8)
check("MU-NSS always reported", "MU-NSS" in srcs)

# NSS register: add real entry -> sample excluded, provenance kept, screening works
nss_backup = sanctions.MU_NSS_FILE.read_text()
try:
    sanctions.add_mu_nss_entry({"name": "Test Domestic Party", "type": "individual",
        "program": "DOMESTIC-TF", "country": "MU", "notice_ref": "GN99/2026",
        "gazette_date": "2026-06-01", "added_by": "tester"})
    nss = sanctions.load_mu_nss()
    check("NSS: sample row excluded after real entry",
          len(nss) == 1 and nss[0]["name"] == "Test Domestic Party")
    allrecs2, st2 = sanctions.load_all()
    mu = [x for x in st2 if x.code == "MU-NSS"][0]
    check("NSS: included in load_all as live", mu.source == "live" and mu.count == 1)
    rr = matching.screen_name("Test Domestic Party", allrecs2)
    check("NSS: screened with provenance",
          rr.hits and rr.hits[0].record.get("notice_ref") == "GN99/2026")
finally:
    sanctions.MU_NSS_FILE.write_text(nss_backup)
check("NSS: register restored to template", len(sanctions.load_mu_nss()) == 0)

# ---------------------------------------------------------------- legislation
section("legislation — corpus integrity & search")
from fcc_suite import legislation

acts = legislation.acts()
check("9 acts loaded", len(acts) == 9, f"(got {len(acts)})")
ids = {a["id"] for a in acts}
for want in ["amla-2026", "fiamla-2002", "fcc-act-2023", "fsa-2007",
             "banking-act-2004", "un-sanctions-act-2019", "poca-2002",
             "admin-penalties-2025", "fiaml-regs-2018"]:
    check(f"act present: {want}", want in ids)
check("every act has summary+obligations",
      all(a.get("summary") and a.get("obligations") for a in acts))
h = legislation.search("proliferation financing CPF")
check("CPF search -> AMLA 2026 first", h and h[0].act["id"] == "amla-2026")
h2 = legislation.search("s.18")
check("section search -> FIAMLA first", h2 and h2[0].act["id"] == "fiamla-2002")
h3 = legislation.search("administrative penalties MUR 250000")
check("penalties search -> GN112/2025 ranked", any(x.act["id"] == "admin-penalties-2025" for x in h3[:2]))
check("obligations index non-empty", len(legislation.obligations_index()) >= 20)
check("get_act returns None for unknown", legislation.get_act("nope") is None)

# ---------------------------------------------------------------- risk
section("risk — scoring, banding, pillars")
from fcc_suite import risk

r0 = risk.assess(country="MU")
check("clean MU client -> LOW / 0", r0.band == "LOW" and r0.score == 0)
r1 = risk.assess(country="IR")
check("IR engages CPF pillar", "CPF" in r1.pillar_flags)
r2 = risk.assess(country="KE")
check("grey-list country partial points", 0 < r2.score < 25, f"(got {r2.score})")
r3 = risk.assess(sanctions_band="STRONG")
check("STRONG sanction -> PROHIBITED regardless of score", r3.band == "PROHIBITED")
r4 = risk.assess(country="KP", is_pep=True, sanctions_band="PROBABLE",
                 product_risk="high", delivery_nonface=True, adverse_media=True,
                 cash_intensive=True, complex_structure=True)
check("worst case capped at 100", r4.score <= 100)
check("worst case HIGH + EDD", r4.band == "HIGH" and r4.edd_required)
check("all three pillars fire", set(r4.pillar_flags) == {"ML", "TF", "CPF"})
check("factors are explainable", all(f.rationale for f in r4.factors))
r5 = risk.assess(country="MU", is_pep=True)
check("PEP alone -> not LOW", r5.score >= 20 and r5.band == "LOW" or r5.score == 20)

# ---------------------------------------------------------------- store
section("store — cases, screenings, audit chain, tamper detection, export")
from fcc_suite import store

store.init_db()
cid = store.create_case("T-001", "Ivan Volkov", "individual", "Tester", "note")
check("case created", isinstance(cid, int) and cid >= 1)
try:
    store.create_case("T-001", "Dup", "individual", "Tester")
    check("duplicate ref rejected", False)
except Exception:
    check("duplicate ref rejected", True)

sid = store.add_screening(cid, "Tester", "Ivan Volkov", False, "STRONG", 100.0,
                          [{"matched_name": "Ivan Petrov Volkov", "score": 100.0}])
store.adjudicate_screening(sid, "true_match", "IDs corroborate", "Tester")
scr = store.get_case_screenings(cid)
check("screening stored + adjudicated",
      scr and scr[0]["adjudication"] == "true_match" and scr[0]["rationale"] == "IDs corroborate")
check("hits JSON round-trips", json.loads(scr[0]["hits_json"])[0]["score"] == 100.0)
try:
    store.adjudicate_screening(sid, "banana", "x", "Tester")
    check("invalid adjudication rejected", False)
except ValueError:
    check("invalid adjudication rejected", True)

rid = store.add_risk(cid, "Tester", 96.0, "HIGH", ["ML", "TF", "CPF"],
                     [{"label": "Country", "points": 25}])
check("risk stored", store.get_case_risks(cid)[0]["band"] == "HIGH")
store.update_case_status(cid, "escalated", "Tester")
check("status updated", store.get_case(cid)["status"] == "escalated")
check("list filter by status", len(store.list_cases("escalated")) == 1)

ok, bad = store.verify_audit_chain()
check("audit chain intact", ok and bad is None)
n_events = store.stats()["audit_events"]
# exactly 5: create, screening, adjudicate, risk, status. The rejected duplicate
# case must NOT appear in the log (insert fails before logging).
check("audit events == 5 (failed insert not logged)", n_events == 5, f"(got {n_events})")

# tamper -> detected at exact row
import sqlite3
con = sqlite3.connect(os.environ["FCC_DB"])
con.execute("UPDATE audit_log SET actor='hacker' WHERE id=3")
con.commit(); con.close()
ok2, bad2 = store.verify_audit_chain()
check("tampering detected at exact row", not ok2 and bad2 == 3, f"(got {bad2})")
# restore by rebuilding a clean DB for remaining tests
os.environ["FCC_DB"] = str(Path(tempfile.mkdtemp()) / "test_fcc2.db")
import importlib
importlib.reload(store)
store.init_db()
cid2 = store.create_case("T-002", "Exportee", "entity", "Tester")
store.add_screening(cid2, "Tester", "Exportee", True, "CLEAR", 0.0, [])
exp = store.export_case(cid2)
check("case export has all sections",
      all(k in exp for k in ("case", "screenings", "risk_assessments", "audit_trail")))
check("export JSON-serialisable", bool(json.dumps(exp, default=str)))
check("global audit trail retrievable", len(store.get_audit_trail()) >= 2)

# ---------------------------------------------------------------- ai_engine
section("ai_engine — offline behaviour & grounding corpus")
from fcc_suite import ai_engine

os.environ.pop("ANTHROPIC_API_KEY", None)
check("offline detection", ai_engine.is_available() is False)
res = ai_engine.ask("test")
check("offline ask returns graceful error", res.ok is False and "ANTHROPIC_API_KEY" in (res.error or ""))
corpus = ai_engine._corpus_text()
check("corpus includes AMLA 2026 + FIAMLA s.18",
      "AMLA 2026" in corpus and "s.18" in corpus)
check("corpus substantial (>3000 chars)", len(corpus) > 3000)
for fn in (ai_engine.analyse_red_flags, ai_engine.draft_str_narrative,
           ai_engine.explain_provision, ai_engine.detect_typology):
    out = fn("x")
    check(f"{fn.__name__} degrades gracefully offline", out.ok is False and out.error)

# ---------------------------------------------------------------- news
section("news — feed parsing & filtering")
from fcc_suite import news
from datetime import datetime

rss = b"""<rss><channel>
<item><title>FATF updates grey list</title><link>http://x/1</link>
<description>Money laundering monitoring changes</description>
<pubDate>Mon, 27 Jul 2026 10:00:00 GMT</pubDate></item>
<item><title>Local football results</title><link>http://x/2</link>
<description>sports</description><pubDate>Mon, 27 Jul 2026 09:00:00 GMT</pubDate></item>
</channel></rss>"""
items = news._parse_feed(rss, "TestSrc", "mauritius")
check("RSS parsed (2 items)", len(items) == 2)
kept = [i for i in items if news._relevant(i, require_keyword=True)]
check("keyword filter keeps AML, drops sport", len(kept) == 1 and "FATF" in kept[0].title)
check("date parsed", kept[0].published is not None and kept[0].date_str == "2026-07-27")
atom = b"""<feed xmlns="http://www.w3.org/2005/Atom">
<entry><title>Sanctions designation notice</title>
<link href="http://y/1"/><updated>2026-07-26T00:00:00Z</updated>
<summary>New designation</summary></entry></feed>"""
check("Atom parsed", len(news._parse_feed(atom, "A", "international")) == 1)
check("malformed feed safe", news._parse_feed(b"not xml", "B", "x") == [])

# ---------------------------------------------------------------- app structure
section("app.py — compile & structural checks")
import ast
src = (ROOT / "app.py").read_text()
tree = ast.parse(src)
check("app.py parses", True)
check("7 tabs defined", src.count("with tabs[") == 7)
check("officer gating present", "Enter your officer name" in src)
check("audit chain surfaced in UI", "verify_audit_chain" in src)
check("NSS management UI present", "Manage Mauritius domestic" in src)
check("case export button present", "Export case file" in src)
check("no localStorage/sessionStorage", "localStorage" not in src and "sessionStorage" not in src)

# ---------------------------------------------------------------- summary
print(f"\n{'='*50}\nRESULT: {PASS} passed, {FAIL} failed")
if FAILURES:
    print("FAILURES:")
    for f in FAILURES:
        print(" -", f)
    sys.exit(1)
print("ALL TESTS PASSED ✅")
