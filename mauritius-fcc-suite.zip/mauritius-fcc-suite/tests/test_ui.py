"""
UI verification with Streamlit AppTest: executes app.py server-side and
simulates real interactions (screening, saving to a case, risk assessment).
Run: python3 tests/test_ui.py
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["FCC_DB"] = str(Path(tempfile.mkdtemp()) / "ui_fcc.db")
os.chdir(ROOT)

from streamlit.testing.v1 import AppTest

PASS, FAIL = 0, 0
FAILURES: list[str] = []


def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        FAILURES.append(f"{name} {detail}")
        print(f"  ❌ {name} {detail}")


def no_exceptions(at: AppTest, label: str):
    excs = [str(e.value) for e in at.exception]
    check(f"{label}: no runtime exceptions", not excs, f"-> {excs[:1]}")


print("\n=== UI: initial render ===")
at = AppTest.from_file("app.py", default_timeout=30)
at.run()
no_exceptions(at, "initial render")
check("title rendered", any("Mauritius FCC Suite" in t.value for t in at.title))
check("tabs present", len(at.tabs) == 7, f"(got {len(at.tabs)})")
check("sidebar officer input present", len(at.sidebar.text_input) >= 1)
check("sidebar shows audit chain intact",
      any("intact" in s.value for s in at.sidebar.success))

print("\n=== UI: set officer name ===")
at.sidebar.text_input(key="officer").set_value("M. Prudence").run()
no_exceptions(at, "officer set")

print("\n=== UI: sanctions screening flow ===")
# find the main name input (first non-sidebar text input) and screen a demo name
name_inputs = [ti for ti in at.text_input if ti.key != "officer"]
check("name input present", len(name_inputs) >= 1)
name_inputs[0].set_value("Ivan Volkov")
# click the "Screen" button
screen_btns = [b for b in at.button if b.label == "Screen"]
check("Screen button present", len(screen_btns) == 1)
screen_btns[0].click().run()
no_exceptions(at, "screening run")
body = " ".join(m.value for m in at.markdown)
check("STRONG match rendered", "STRONG" in body and "Ivan Petrov Volkov" in body)
check("adjudication radio appears", any(r.key == "adj_screen" for r in at.radio))
check("MU-NSS source shown", any(m.label == "MU-NSS" for m in at.metric))
check("legal-duty caption for NSSec present",
      any("s.25" in c.value for c in at.caption))

print("\n=== UI: save screening -> inline case creation ===")
at.radio(key="adj_screen").set_value("true_match")
at.text_area(key="rat_screen").set_value("Demo dataset corroboration; escalate.")
at.text_input(key="nref_screen").set_value("CASE-UI-001")
at.text_input(key="nsubj_screen").set_value("Ivan Volkov")
create_btns = [b for b in at.button if b.key == "ncreate_screen"]
check("inline case-create button present", len(create_btns) == 1)
create_btns[0].click().run()
no_exceptions(at, "inline case create")
check("case created feedback", any("created" in s.value for s in at.success))

# screening results were preserved in session_state -> save button should work
save_btns = [b for b in at.button if "Save screening" in b.label]
check("save-screening button present", len(save_btns) == 1)
save_btns[0].click().run()
no_exceptions(at, "save screening")
check("screening saved feedback",
      any("recorded to case" in s.value for s in at.success))

from fcc_suite import store
scr_cases = store.list_cases()
check("case persisted in DB", any(c["ref"] == "CASE-UI-001" for c in scr_cases))
cid = [c["id"] for c in scr_cases if c["ref"] == "CASE-UI-001"][0]
saved = store.get_case_screenings(cid)
check("screening persisted with adjudication",
      saved and saved[0]["adjudication"] == "true_match"
      and saved[0]["band"] == "STRONG")
ok, bad = store.verify_audit_chain()
check("audit chain intact after UI actions", ok, f"(broken at {bad})")

print("\n=== UI: risk assessment flow ===")
at2 = AppTest.from_file("app.py", default_timeout=30)
at2.run()
at2.sidebar.text_input(key="officer").set_value("M. Prudence").run()
at2.text_input(key="risk_country").set_value("IR")
at2.checkbox(key="risk_pep").set_value(True)
at2.selectbox(key="risk_sband").set_value("PROBABLE")
assess = [b for b in at2.button if b.label == "Assess risk"]
assess[0].click().run()
no_exceptions(at2, "risk assess")
metrics = {m.label: m.value for m in at2.metric}
check("risk score metric rendered", "Risk score" in metrics)
# IR (25) + CPF nexus (15) + PEP (20) + PROBABLE (24) = 84 -> HIGH
check("score is 84 as designed", metrics.get("Risk score") == "84.0/100",
      f"(got {metrics.get('Risk score')})")
body2 = " ".join(m.value for m in at2.markdown)
check("HIGH band rendered", ">HIGH<" in body2)
check("EDD error banner shown", any("Enhanced Due Diligence" in e.value for e in at2.error))
check("CPF distinct-assessment info shown",
      any("distinct proliferation-financing" in i.value for i in at2.info))
# verify session_state carries the result for the save step
check("risk result staged for saving", "risk_result" in at2.session_state)

print("\n=== UI: legislation search ===")
at3 = AppTest.from_file("app.py", default_timeout=30)
at3.run()
leg_q = [ti for ti in at3.text_input if "Search the framework" in (ti.label or "")]
check("legislation search box present", len(leg_q) == 1)
leg_q[0].set_value("proliferation financing").run()
no_exceptions(at3, "legislation search")
exp_titles = " ".join(e.label for e in at3.expander)
check("AMLA 2026 surfaced", "AMLA 2026" in exp_titles)

print("\n=== UI: AI tab offline behaviour ===")
warns = [w.value for w in at3.warning]
check("AI offline warning shown", any("ANTHROPIC_API_KEY" in w for w in warns))
run_btns = [b for b in at3.button if b.label == "Run analysis"]
check("Run analysis disabled offline", run_btns and run_btns[0].disabled)

print("\n=== UI: NSS domestic-list management ===")
at4 = AppTest.from_file("app.py", default_timeout=30)
at4.run()
at4.sidebar.text_input(key="officer").set_value("M. Prudence").run()
from fcc_suite import sanctions
nss_backup = sanctions.MU_NSS_FILE.read_text()
try:
    at4.text_input(key="nss_name").set_value("UI Domestic Test")
    at4.text_input(key="nss_ref").set_value("GN77/2026")
    add_btns = [b for b in at4.button if b.label == "Add domestic designation"]
    check("NSS add button present", len(add_btns) == 1)
    add_btns[0].click().run()
    no_exceptions(at4, "NSS add")
    check("NSS entry persisted with provenance",
          any(e["name"] == "UI Domestic Test" and e.get("notice_ref") == "GN77/2026"
              for e in sanctions.load_mu_nss()))
    check("NSS designation audit-logged",
          any(e["action"] == "nss.designate" for e in store.get_audit_trail()))
finally:
    sanctions.MU_NSS_FILE.write_text(nss_backup)

print(f"\n{'='*50}\nUI RESULT: {PASS} passed, {FAIL} failed")
if FAILURES:
    for f in FAILURES:
        print(" -", f)
    sys.exit(1)
print("ALL UI TESTS PASSED ✅")
