# Mauritius FCC Suite

AML / CFT / CPF compliance-intelligence toolkit for compliance officers, MLROs and
financial-crime specialists operating under the **Mauritian** framework —
FIU · FSC · FCC · Bank of Mauritius regulated entities.

Built around the current framework: **FIAMLA 2002 → AMLA 2026** (the 2026 Act adds
**Countering Proliferation Financing (CPF)** as a mandatory third pillar).

---

## Modules

| Module | What it does | Works offline? |
|---|---|---|
| **Sanctions screening** | Live-fetches UN / OFAC / UK OFSI lists + the **Mauritius domestic (NSSec) list**, caches them, fuzzy-matches names (recall-biased), bands results STRONG→CLEAR | ✅ (demo dataset fallback) |
| **Risk assessment** | Transparent, explainable weighted model across ML / TF / CPF pillars; flags EDD | ✅ |
| **Cases & audit** | Records every screening, adjudication and risk snapshot to a case file, with a **tamper-evident, hash-chained audit log** and JSON/CSV export | ✅ |
| **Legislation library** | Searchable, curated map of the Mauritian framework to the right Act/section | ✅ |
| **AI analyst** | Red-flag review, typology detection, STR-narrative drafting, provision Q&A — grounded in the local corpus | Needs API key |
| **News monitor** | FATF / OFAC / UN + keyword-filtered local coverage via RSS | Needs network |

## Mauritius domestic sanctions list (NSSec)

Screening against **both** the UN Consolidated List **and** the Mauritius domestic list
is a **legal duty** under the UN Sanctions Act 2019 (s.25 — verify on every new
designation). The domestic list is published as NSSec public notices / Gazette
entries, not a machine feed, so it is maintained locally in
`fcc_suite/data/mu_nss.json` with full provenance (notice ref, Gazette date,
designation date). Add designations via the app (Sanctions ▸ *Manage Mauritius
domestic list*) — each addition is written to the audit log. The domestic list is
**always** included in screening, never optional.

## Cases & tamper-evident audit trail

Every decision an inspector would want to see is recorded in a local SQLite store
(`fcc_runtime.db`, stdlib only — no server):

- **Cases** — reference, subject, status (open → edd → escalated → str_filed → closed).
- **Screenings** — query, band, score, the matched records, the **adjudication**
  (true match / false positive / needs review) and the officer's **rationale**.
- **Risk snapshots** — score, band, pillars and factors at the point of decision.
- **Audit log** — append-only and **SHA-256 hash-chained**: each event stores the
  previous event's hash, so any later edit or deletion breaks the chain.
  `verify_audit_chain()` (shown live in the sidebar) reports whether records are
  intact and, if not, the exact event where tampering occurred.

Export a full case file as JSON or the entire audit log as CSV from the
*Cases & Audit* tab. Set the operator name in the sidebar so decisions are
attributed. Point the DB elsewhere with `export FCC_DB=/path/to/fcc.db`.

## Verification status

The shipped build passes a three-gate verification (re-run any time):

```bash
python3 tests/test_suite.py   # 85 unit/integration checks — all modules
python3 tests/test_ui.py      # 38 UI checks — real interactions via Streamlit AppTest
streamlit run app.py          # live server boot
```

**2026-07-28 update:** `requirements.txt` had a broken line (a `;` after a
package spec is parsed by pip as a PEP 508 environment marker, not a comment
— `anthropic>=0.40 ; optional, only needed for...` raised `InvalidMarker` and
would have failed every clean install, including on Streamlit Cloud). Fixed
and re-verified with a clean `pip install -r requirements.txt` in an isolated
virtualenv. `ai_engine.py` was also hardened to check `st.secrets` as a
fallback if `ANTHROPIC_API_KEY` isn't mirrored into the environment on your
hosting platform.

Coverage includes: fuzzy matching (accents, corporate suffixes, aliases, transliteration,
thresholds), all three sanctions parsers (UN XML, OFAC CSV, UK OFSI CSV), cache round-trip
and offline fallback, the NSS domestic register (provenance, sample exclusion, screening),
legislation corpus integrity and search ranking, risk banding across all pillars
(including the PROHIBITED override on a STRONG sanctions hit), case lifecycle, screening
adjudication, **audit-chain tamper detection at the exact corrupted row**, case export,
graceful AI-offline degradation, RSS/Atom parsing with keyword filtering, and full UI
flows (screen → adjudicate → create case inline → save; risk assess → EDD banner;
NSS designation with audit logging).

Note: live UN/OFAC/UK fetches and news feeds were verified for *graceful fallback* in the
build sandbox (no outbound network); run once on a normal connection to populate real lists.

## Deploying from a phone

No computer needed — see **[DEPLOY_GUIDE.md](DEPLOY_GUIDE.md)** for a full
walkthrough: unzip on-device, upload to GitHub folder-by-folder via mobile
browser, deploy free on Streamlit Community Cloud, get a real `.streamlit.app`
link.

## Quick start

```bash
pip install -r requirements.txt
# optional — enables the AI analyst tab:
export ANTHROPIC_API_KEY=sk-ant-...
streamlit run app.py
```

Or just: `bash run.sh`

## Architecture

```
app.py                     Streamlit UI (7 tabs)
fcc_suite/
  legislation.py           curated corpus + search        -> data/legislation.json
  sanctions.py             list fetch/cache/parse + NSS    -> data/sanctions_cache/, data/mu_nss.json
  matching.py              normalisation + fuzzy screening
  risk.py                  weighted ML/TF/CPF risk model
  store.py                 SQLite cases + hash-chained audit log
  ai_engine.py             Anthropic-grounded analyst
  news.py                  RSS monitor
  data/                    legislation.json, sample_sanctions.json, mu_nss.json
fcc_runtime.db             created at runtime (cases + audit; override with FCC_DB)
```

The design is deliberately modular: the deterministic engines (screening, risk,
legislation) run with **no external dependency and no API key**, so the tool is
useful the moment it is installed. The AI layer is additive.

## What is real vs. what you must wire in

**Real and working now**
- Fuzzy name screening with corporate-suffix and accent handling.
- Explainable risk scoring aligned to the FSC Handbook risk categories.
- Curated legislation metadata for the Mauritian framework (accurate as of 2026-07).
- AI analyst (with your Anthropic key) grounded in that corpus.

**You must supply / verify for production**
- **Sanctions sources**: URLs in `sanctions.py > SOURCES` are the public UN/OFAC/UK
  endpoints — verify them and add **EU** (needs an access token) and the
  **Mauritius National Sanctions Secretariat** list (UN Sanctions Act 2019).
- **Legislation text**: this ships with *practitioner summaries and provision
  references*, **not** the official Gazette text. Always verify against the
  consolidated Act. Load full texts you are licensed to use.
- **FATF country lists** in `risk.py` change at each plenary — refresh them.
- **News feeds** in `news.py` — swap in the feeds you rely on.

## Important limitations

This is a **decision-support** tool, not legal advice and not a determination.
A human MLRO must adjudicate every match, EDD decision and any STR to the FIU.
Automated screening is recall-biased by design: it will produce false positives
that require analyst review — that is the intended, defensible posture.

## Commercialisation notes

The defensible value ("moat") is **not** the screening code — that is a commodity.
It is: (1) the encoded **Mauritius-specific** mapping of fact patterns → statute →
obligation, (2) integration of **local** sanctions (NSS) alongside global lists,
(3) AI reasoning grounded in the Mauritian corpus, and (4) the CPF pillar built in
from day one under AMLA 2026. Keep the legislation corpus current and that stays hard
to replicate. Position as a per-seat SaaS for FSC-licensed management companies and
DNFBP-sector firms; the MUR 250,000 administrative-penalty regime (GN 112/2025) is
the commercial argument.

---
*Not affiliated with the FSC, FCC, FIU or Bank of Mauritius.*
